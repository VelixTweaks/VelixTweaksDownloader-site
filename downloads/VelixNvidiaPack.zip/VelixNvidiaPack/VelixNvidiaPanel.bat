@echo off
:: Set UTF-8 encoding to fix the corrupted text shown in image_70dd82.png
chcp 65001 >nul 2>&1
cls
title Velix NVIDIA Optimizer
mode 120,35
color 0f

:: Request Admin Privileges
fltmc >nul 2>&1 || (
    echo Administrator privileges are required.
    PowerShell Start -Verb RunAs '%0' 2> nul || (
        echo Right-click on the script and select "Run as administrator".
        pause
    )
    exit /b
)

:main
cls
echo.
echo.
echo.
echo                                          ██╗   ██╗███████╗██╗     ██╗██╗  ██╗
echo                                          ██║   ██║██╔════╝██║     ██║╚██╗██╔╝
echo                                          ██║   ██║█████╗  ██║     ██║ ╚███╔╝ 
echo                                          ╚██╗ ██╔╝██╔══╝  ██║     ██║ ██╔██╗ 
echo                                           ╚████╔╝ ███████╗███████╗██║██╔╝ ██╗
echo                                            ╚═══╝  ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝
echo                                           [ N V I D I A   O P T I M I Z E R ]
echo.                                                                                                                                                                                                                                                                                                                                     
echo                          ----------------------------------------------------------------------                                                                     
echo.
echo.
echo                                              [0] Create System Restore Point
echo.
echo                                              [1] Enable Hardware Accelerated GPU Scheduling
echo.
echo                                              [2] Optimize GPU Priority (MMCSS Tweaks)
echo.
echo                                              [3] Disable Windows GPU Power Throttling
echo.
echo                                              [4] Clear NVIDIA Shader Caches
echo.
echo                                              [5] Apply ALL Optimizations (1-4)
echo.
echo                                              [R] Revert All
echo.
echo.
set /p choice="                                              Choose an option: "

if "%choice%"=="0" goto restore
if "%choice%"=="1" goto hags
if "%choice%"=="2" goto mmcss
if "%choice%"=="3" goto power
if "%choice%"=="4" goto cache
if "%choice%"=="5" goto all
if /I "%choice%"=="r" goto revert
goto main

:restore
cls
echo Creating Manual System Restore Point...
powershell.exe -Command "Checkpoint-Computer -Description 'Velix NVIDIA Optimizer Restore Point' -RestorePointType 'MODIFY_SETTINGS'"
echo.
echo   Restore Point Created Successfully.
echo =======================================
echo.  
pause
goto main

:hags
cls
echo Enabling Hardware Accelerated GPU Scheduling (HAGS)...
reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v "HwSchMode" /t REG_DWORD /d "2" /f
echo.
echo   Press Any Key to Continue (A Restart is required to apply HAGS)
echo =================================================================
echo.  
pause
goto main

:mmcss
cls
echo Optimizing System Responsiveness and GPU Task Priority...
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "SystemResponsiveness" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "GPU Priority" /t REG_DWORD /d "8" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "Priority" /t REG_DWORD /d "6" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "Scheduling Category" /t REG_SZ /d "High" /f
echo.
echo   Press Any Key to Continue
echo ==============================
echo.  
pause
goto main

:power
cls
echo Disabling Windows Power Throttling...
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling" /v "PowerThrottlingOff" /t REG_DWORD /d "1" /f
echo.
echo   Press Any Key to Continue
echo ==============================
echo.  
pause
goto main

:cache
cls
echo Clearing NVIDIA DirectX and OpenGL Shader Caches...
del /q /s /f "%localappdata%\NVIDIA\DXCache\*" >nul 2>&1
del /q /s /f "%localappdata%\NVIDIA\GLCache\*" >nul 2>&1
del /q /s /f "%data%\NVIDIA Corporation\NV_Cache\*" >nul 2>&1
echo.
echo   Press Any Key to Continue
echo ==============================
echo.  
pause
goto main

:all
cls
echo Applying ALL Velix NVIDIA Optimizations...
reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v "HwSchMode" /t REG_DWORD /d "2" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "SystemResponsiveness" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "GPU Priority" /t REG_DWORD /d "8" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "Priority" /t REG_DWORD /d "6" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "Scheduling Category" /t REG_SZ /d "High" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling" /v "PowerThrottlingOff" /t REG_DWORD /d "1" /f
del /q /s /f "%localappdata%\NVIDIA\DXCache\*" >nul 2>&1
del /q /s /f "%localappdata%\NVIDIA\GLCache\*" >nul 2>&1
echo.
echo   All Tweaks Applied. Please restart your PC for maximum effect.
echo ================================================================
echo.  
pause
goto main

:revert
cls
echo Reverting NVIDIA Optimizations to Windows Defaults...
reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v "HwSchMode" /t REG_DWORD /d "1" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "SystemResponsiveness" /t REG_DWORD /d "20" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "GPU Priority" /t REG_DWORD /d "8" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "Priority" /t REG_DWORD /d "2" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "Scheduling Category" /t REG_SZ /d "Medium" /f
reg delete "HKLM\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling" /v "PowerThrottlingOff" /f >nul 2>&1
echo.
echo   System Defaults Restored.
echo ==============================
echo.  
pause
goto main