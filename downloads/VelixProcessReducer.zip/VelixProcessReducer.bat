@echo off
cls
title Velix Process Reducer
:: Check if C:\temp exists, if not, create it
if not exist "C:\temp\" mkdir "C:\temp\"
echo [-] Creating System Restore Point (Velix Process Reducer Restore Point)
powershell.exe -Command "Checkpoint-Computer -Description 'Velix Process Reducer' -RestorePointType 'MODIFY_SETTINGS'"
cls
mode 120,35
set w=[97m
set p=[95m
set b=[96m

:main
chcp 65001 >nul 2>&1
cls
color 0
echo.
echo.
echo.
echo                                          ██╗   ██╗███████╗██╗     ██╗██╗  ██╗
echo                                          ██║   ██║██╔════╝██║     ██║╚██╗██╔╝
echo                                          ██║   ██║█████╗  ██║     ██║ ╚███╔╝ 
echo                                          ╚██╗ ██╔╝██╔══╝  ██║     ██║ ██╔██╗ 
echo                                           ╚████╔╝ ███████╗███████╗██║██╔╝ ██╗
echo                                            ╚═══╝  ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝
echo                                           [ P R O C E S S   R E D U C E R ]
echo.                                                                                                                                                                                                                                                                                                                                     
echo                          ----------------------------------------------------------------------                                                                     
echo.
echo.
echo.
echo                                              [1] Disable Microsoft Store
echo.
echo                                              [2] Disable Xbox Services
echo.
echo                                              [3] Disable SysMain
echo.
echo                                              [4] Disable Wifi Services
echo.
echo                                              [5] Disable Bluetooth
echo.
echo                                              [6] Disable Printer Services
echo.
echo                                              [7] Disable Useless Services
echo.
echo                                              [R] Revert All
echo.
echo.
set /p choice="                                              Choose an option: "

if "%choice%"=="1" goto msstore
if "%choice%"=="2" goto xbox
if "%choice%"=="3" goto sysmain
if "%choice%"=="4" goto wifi
if "%choice%"=="5" goto bluetooth
if "%choice%"=="6" goto printer
if "%choice%"=="7" goto useless
if /I "%choice%"=="r" goto revert
goto main

:msstore
cls
echo Disabling Microsoft Store and Update Services...
sc stop ClipSVC
sc stop uhssvc
sc stop upfc
sc stop PushToInstall
sc stop BITS
sc stop InstallService
sc stop UsoSvc
sc config ClipSVC start= disabled
sc config BITS start= disabled
sc config InstallService start= disabled
sc config uhssvc start= disabled
sc config UsoSvc start= disabled
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\DoSvc" /v Start /t reg_dword /d 4 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\InstallService" /v Start /t reg_dword /d 4 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\UsoSvc" /v Start /t reg_dword /d 4 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\wuauserv" /v Start /t reg_dword /d 4 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\WaaSMedicSvc" /v Start /t reg_dword /d 4 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\BITS" /v Start /t reg_dword /d 4 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\upfc" /v Start /t reg_dword /d 4 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\uhssvc" /v Start /t reg_dword /d 4 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\ossrs" /v Start /t reg_dword /d 4 /f
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v "DeferUpdatePeriod" /t REG_DWORD /d "1" /f
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v "DeferUpgrade" /t REG_DWORD /d "1" /f
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v "DeferUpgradePeriod" /t REG_DWORD /d "1" /f
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v "DisableWindowsUpdateAccess" /t REG_DWORD /d "1" /f
schtasks /Change /TN "Microsoft\Windows\InstallService\ScanForUpdates" /Disable
schtasks /Change /TN "Microsoft\Windows\InstallService\ScanForUpdatesAsUser" /Disable
schtasks /Change /TN "Microsoft\Windows\InstallService\SmartRetry" /Disable
schtasks /Change /TN "Microsoft\Windows\InstallService\WakeUpAndContinueUpdates" /Disable
schtasks /Change /TN "Microsoft\Windows\InstallService\WakeUpAndScanForUpdates" /Disable
schtasks /Change /TN "Microsoft\Windows\UpdateOrchestrator\Report policies" /Disable
schtasks /Change /TN "Microsoft\Windows\UpdateOrchestrator\Schedule Scan" /Disable
schtasks /Change /TN "Microsoft\Windows\UpdateOrchestrator\Schedule Scan Static Task" /Disable
schtasks /Change /TN "Microsoft\Windows\UpdateOrchestrator\UpdateModelTask" /Disable
schtasks /Change /TN "Microsoft\Windows\UpdateOrchestrator\USO_UxBroker" /Disable
schtasks /Change /TN "Microsoft\Windows\WaaSMedic\PerformRemediation" /Disable
schtasks /Change /TN "Microsoft\Windows\WindowsUpdate\Scheduled Start" /Disable
echo.
echo   Press Any Key to Continue
echo ==============================
echo.  
pause
cls
goto main

:xbox
cls
echo Disabling Xbox and GameDVR Services...
sc stop xbgm
sc stop XboxGipSvc
sc stop XblAuthManager
sc stop XboxNetApiSvc
sc stop XblGameSave
sc config xbgm start= disabled
sc config XboxGipSvc start= disabled
sc config XblAuthManager start= disabled
sc config XboxNetApiSvc start= disabled
sc config XblGameSave start= disabled
reg add "HKLM\System\CurrentControlSet\Services\xbgm" /v "Start" /t REG_DWORD /d "4" /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v "AppCaptureEnabled" /t REG_DWORD /d "0" /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v "AudioCaptureEnabled" /t REG_DWORD /d "0" /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v "CursorCaptureEnabled" /t REG_DWORD /d "0" /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v "MicrophoneCaptureEnabled" /t REG_DWORD /d "0" /f
reg add "HKCU\System\GameConfigStore" /v "GameDVR_FSEBehavior" /t REG_DWORD /d "2" /f
reg add "HKCU\System\GameConfigStore" /v "GameDVR_HonorUserFSEBehaviorMode" /t REG_DWORD /d "2" /f
reg add "HKCU\System\GameConfigStore" /v "GameDVR_Enabled" /t REG_DWORD /d "0" /f
reg add "HKLM\Software\Policies\Microsoft\Windows\GameDVR" /v "AllowgameDVR" /t REG_DWORD /d "0" /f
reg add "HKCU\Software\Microsoft\GameBar" /v "AutoGameModeEnabled" /t REG_DWORD /d "0" /f
schtasks /Change /TN "Microsoft\XblGameSave\XblGameSaveTask" /Disable
echo.
echo   Press Any Key to Continue
echo ==============================
echo.  
pause
cls
goto main

:sysmain
cls
echo Disabling SysMain (Superfetch)...
sc stop SysMain
sc config SysMain start= disabled
schtasks /Change /TN "Microsoft\Windows\Sysmain\ResPriStaticDbSync" /Disable
schtasks /Change /TN "Microsoft\Windows\Sysmain\WsSwapAssessmentTask" /Disable
echo.
echo   Press Any Key to Continue
echo ==============================
echo.  
pause
cls
goto main

:wifi
cls
echo Disabling Wi-Fi Services (WlanSvc)...
sc stop WlanSvc
sc config WlanSvc start= disabled
sc stop vwififlt
sc config vwififlt start= disabled
echo.
echo   Press Any Key to Continue
echo ==============================
echo.  
pause
cls
goto main

:bluetooth
cls
echo Disabling Bluetooth Services...
sc stop BTAGService
sc stop bthserv
sc config BTAGService start= disabled
sc config bthserv start= disabled
echo.
echo   Press Any Key to Continue
echo ==============================
echo.  
pause
cls
goto main

:printer
cls
echo Disabling Printer Services...
sc stop PrintNotify
sc stop Spooler
sc config PrintNotify start= disabled
sc config Spooler start= disabled
schtasks /Change /TN "Microsoft\Windows\Printing\EduPrintProv" /Disable
schtasks /Change /TN "Microsoft\Windows\Printing\PrinterCleanupTask" /Disable
echo.
echo   Press Any Key to Continue
echo ==============================
echo.  
pause
cls
goto main

:useless
cls
echo Disabling Telemetry and Background Services...
reg add "HKLM\System\CurrentControlSet\Services\PimIndexMaintenanceSvc" /v "Start" /t REG_DWORD /d "4" /f
reg add "HKLM\System\CurrentControlSet\Services\BcastDVRUserService" /v "Start" /t REG_DWORD /d "4" /f
sc stop wlidsvc
sc stop DiagTrack
sc stop DusmSvc
sc stop RetailDemo
sc stop Fax
sc stop lfsvc
sc stop WpcMonSvc
sc stop SessionEnv
sc stop MicrosoftEdgeElevationService
sc stop edgeupdate
sc stop edgeupdatem
sc stop autotimesvc
sc stop CscService
sc stop TermService
sc stop SensrSvc
sc stop shpamsvc
sc stop diagnosticshub.standardcollector.service
sc stop PhoneSvc
sc stop TapiSrv
sc stop UevAgentService
sc stop WalletService
sc stop TokenBroker
sc stop WebClient
sc stop MixedRealityOpenXRSvc
sc stop stisvc
sc stop WbioSrvc
sc stop Wecsvc
sc stop SEMgrSvc
sc config wlidsvc start= disabled
sc config DiagTrack start= disabled
sc config DusmSvc start= disabled
sc config RetailDemo start= disabled
sc config Fax start= disabled
sc config lfsvc start= disabled
sc config WpcMonSvc start= disabled
sc config SessionEnv start= disabled
sc config MicrosoftEdgeElevationService start= disabled
sc config edgeupdate start= disabled
sc config edgeupdatem start= disabled
sc config autotimesvc start= disabled
sc config CscService start= disabled
sc config TermService start= disabled
sc config SensrSvc start= disabled
sc config shpamsvc start= disabled
sc config diagnosticshub.standardcollector.service start= disabled
sc config PhoneSvc start= disabled
sc config TapiSrv start= disabled
sc config UevAgentService start= disabled
sc config WalletService start= disabled
sc config TokenBroker start= disabled
sc config WebClient start= disabled
sc config MixedRealityOpenXRSvc start= disabled
sc config stisvc start= disabled
sc config WbioSrvc start= disabled
sc config Wecsvc start= disabled
sc config SEMgrSvc start= disabled
sc config Backupper Service start= disabled
sc config BthAvctpSvc start= disabled
sc config BDESVC start= disabled
sc config cbdhsvc start= disabled
sc config CDPSvc start= disabled
sc config DevQueryBroker start= disabled
sc config dmwappushservice start= disabled
sc config TrkWks start= disabled
sc config dLauncherLoopback start= disabled
sc config EFS start= disabled
sc config fdPHost start= disabled
sc config FDResPub start= disabled
sc config IKEEXT start= disabled
sc config WPDBusEnum start= disabled
sc config PcaSvc start= disabled
sc config RasMan start= disabled
sc config RetailDemo start=disabled
sc config SstpSvc start=disabled
sc config SSDPSRV start= disabled
sc config OneSyncSvc start= disabled
sc config FontCache start= disabled
sc config W32Time start= disabled
sc config tzautoupdate start= disabled
sc config DsSvc start= disabled
sc config diagsvc start= disabled
sc config DialogBlockingService start= disabled
sc config PimIndexMaintenanceSvc_5f1ad start= disabled
sc config MessagingService_5f1ad start= disabled
sc config AppVClient start= disabled
sc config MsKeyboardFilter start= disabled
sc config ssh-agent start= disabled
sc config SstpSvc start= disabled
sc config OneSyncSvc_5f1ad start= disabled
sc config wercplsupport start= disabled
sc config WerSvc start= disabled
sc config WpnUserService_5f1ad start= disabled
sc config DsmSvc start= disabled

schtasks /DELETE /TN "AMDInstallLauncher" /f
schtasks /DELETE /TN "AMDLinkUpdate" /f
schtasks /DELETE /TN "AMDRyzenMasterSDKTask" /f
schtasks /DELETE /TN "Driver Easy Scheduled Scan" /f
schtasks /DELETE /TN "ModifyLinkUpdate" /f
schtasks /DELETE /TN "SoftMakerUpdater" /f
schtasks /DELETE /TN "StartCN" /f
schtasks /DELETE /TN "StartDVR" /f

schtasks /Change /TN "Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser" /Disable
schtasks /Change /TN "Microsoft\Windows\Application Experience\PcaPatchDbTask" /Disable
schtasks /Change /TN "Microsoft\Windows\Application Experience\ProgramDataUpdater" /Disable
schtasks /Change /TN "Microsoft\Windows\Application Experience\StartupAppTask" /Disable
schtasks /Change /TN "Microsoft\Windows\Autochk\Proxy" /Disable
schtasks /Change /TN "Microsoft\Windows\Customer Experience Improvement Program\Consolidator" /Disable
schtasks /Change /TN "Microsoft\Windows\Customer Experience Improvement Program\UsbCeip" /Disable
schtasks /Change /TN "Microsoft\Windows\Defrag\ScheduledDefrag" /Disable
schtasks /Change /TN "Microsoft\Windows\Device Information\Device User" /Disable
schtasks /Change /TN "Microsoft\Windows\Diagnosis\RecommendedTroubleshootingScanner" /Disable
schtasks /Change /TN "Microsoft\Windows\Diagnosis\Scheduled" /Disable
schtasks /Change /TN "Microsoft\Windows\DiskCleanup\SilentCleanup" /Disable
schtasks /Change /TN "Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector" /Disable
schtasks /Change /TN "Microsoft\Windows\DiskFootprint\Diagnostics" /Disable
schtasks /Change /TN "Microsoft\Windows\DiskFootprint\StorageSense" /Disable
schtasks /Change /TN "Microsoft\Windows\DUSM\dusmtask" /Disable
schtasks /Change /TN "Microsoft\Windows\EnterpriseMgmt\MDMMaintenenceTask" /Disable
schtasks /Change /TN "Microsoft\Windows\Feedback\Siuf\DmClient" /Disable
schtasks /Change /TN "Microsoft\Windows\Feedback\Siuf\DmClientOnScenarioDownload" /Disable
schtasks /Change /TN "Microsoft\Windows\FileHistory\File History (maintenance mode)" /Disable
schtasks /Change /TN "Microsoft\Windows\Flighting\FeatureConfig\ReconcileFeatures" /Disable
schtasks /Change /TN "Microsoft\Windows\Flighting\FeatureConfig\UsageDataFlushing" /Disable
schtasks /Change /TN "Microsoft\Windows\Flighting\FeatureConfig\UsageDataReporting" /Disable
schtasks /Change /TN "Microsoft\Windows\Flighting\OneSettings\RefreshCache" /Disable
schtasks /Change /TN "Microsoft\Windows\Input\LocalUserSyncDataAvailable" /Disable
schtasks /Change /TN "Microsoft\Windows\Input\MouseSyncDataAvailable" /Disable
schtasks /Change /TN "Microsoft\Windows\Input\PenSyncDataAvailable" /Disable
schtasks /Change /TN "Microsoft\Windows\Input\TouchpadSyncDataAvailable" /Disable
schtasks /Change /TN "Microsoft\Windows\International\Synchronize Language Settings" /Disable
schtasks /Change /TN "Microsoft\Windows\LanguageComponentsInstaller\Installation" /Disable
schtasks /Change /TN "Microsoft\Windows\LanguageComponentsInstaller\ReconcileLanguageResources" /Disable
schtasks /Change /TN "Microsoft\Windows\LanguageComponentsInstaller\Uninstallation" /Disable
schtasks /Change /TN "Microsoft\Windows\License Manager\TempSignedLicenseExchange" /Disable
schtasks /Change /TN "Microsoft\Windows\Management\Provisioning\Cellular" /Disable
schtasks /Change /TN "Microsoft\Windows\Management\Provisioning\Logon" /Disable
schtasks /Change /TN "Microsoft\Windows\Maintenance\WinSAT" /Disable
schtasks /Change /TN "Microsoft\Windows\Maps\MapsToastTask" /Disable
schtasks /Change /TN "Microsoft\Windows\Maps\MapsUpdateTask" /Disable
schtasks /Change /TN "Microsoft\Windows\Mobile Broadband Accounts\MNO Metadata Parser" /Disable
schtasks /Change /TN "Microsoft\Windows\MUI\LPRemove" /Disable
schtasks /Change /TN "Microsoft\Windows\NetTrace\GatherNetworkInfo" /Disable
schtasks /Change /TN "Microsoft\Windows\PI\Sqm-Tasks" /Disable
schtasks /Change /TN "Microsoft\Windows\Power Efficiency Diagnostics\AnalyzeSystem" /Disable
schtasks /Change /TN "Microsoft\Windows\PushToInstall\Registration" /Disable
schtasks /Change /TN "Microsoft\Windows\Ras\MobilityManager" /Disable
schtasks /Change /TN "Microsoft\Windows\RecoveryEnvironment\VerifyWinRE" /Disable
schtasks /Change /TN "Microsoft\Windows\RemoteAssistance\RemoteAssistanceTask" /Disable
schtasks /Change /TN "Microsoft\Windows\RetailDemo\CleanupOfflineContent" /Disable
schtasks /Change /TN "Microsoft\Windows\Servicing\StartComponentCleanup" /Disable
schtasks /Change /TN "Microsoft\Windows\SettingSync\NetworkStateChangeTask" /Disable
schtasks /Change /TN "Microsoft\Windows\Setup\SetupCleanupTask" /Disable
schtasks /Change /TN "Microsoft\Windows\Setup\SnapshotCleanupTask" /Disable
schtasks /Change /TN "Microsoft\Windows\SpacePort\SpaceAgentTask" /Disable
schtasks /Change /TN "Microsoft\Windows\SpacePort\SpaceManagerTask" /Disable
schtasks /Change /TN "Microsoft\Windows\Speech\SpeechModelDownloadTask" /Disable
schtasks /Change /TN "Microsoft\Windows\Storage Tiers Management\Storage Tiers Management Initialization" /Disable
schtasks /Change /TN "Microsoft\Windows\Task Manager\Interactive" /Disable
schtasks /Change /TN "Microsoft\Windows\Time Synchronization\ForceSynchronizeTime" /Disable
schtasks /Change /TN "Microsoft\Windows\Time Synchronization\SynchronizeTime" /Disable
schtasks /Change /TN "Microsoft\Windows\Time Zone\SynchronizeTimeZone" /Disable
schtasks /Change /TN "Microsoft\Windows\TPM\Tpm-HASCertRetr" /Disable
schtasks /Change /TN "Microsoft\Windows\TPM\Tpm-Maintenance" /Disable
schtasks /Change /TN "Microsoft\Windows\UPnP\UPnPHostConfig" /Disable
schtasks /Change /TN "Microsoft\Windows\User Profile Service\HiveUploadTask" /Disable
schtasks /Change /TN "Microsoft\Windows\WDI\ResolutionHost" /Disable
schtasks /Change /TN "Microsoft\Windows\Windows Filtering Platform\BfeOnServiceStartTypeChange" /Disable
schtasks /Change /TN "Microsoft\Windows\WOF\WIM-Hash-Management" /Disable
schtasks /Change /TN "Microsoft\Windows\WOF\WIM-Hash-Validation" /Disable
schtasks /Change /TN "Microsoft\Windows\Work Folders\Work Folders Logon Synchronization" /Disable
schtasks /Change /TN "Microsoft\Windows\Work Folders\Work Folders Maintenance Work" /Disable
schtasks /Change /TN "Microsoft\Windows\Workplace Join\Automatic-Device-Join" /Disable
schtasks /Change /TN "Microsoft\Windows\WwanSvc\NotificationTask" /Disable
schtasks /Change /TN "Microsoft\Windows\WwanSvc\OobeDiscovery" /Disable
echo.
echo   Press Any Key to Continue
echo ==============================
echo.  
pause
cls
goto main

:revert
cls
echo Reverting all changes (Restoring default services)...
sc config "AppVClient" start= auto >nul 2>&1
sc config "BDESVC" start= auto >nul 2>&1
sc config "BITS" start= auto >nul 2>&1
sc config "BTAGService" start= auto >nul 2>&1
sc config "BthAvctpSvc" start= auto >nul 2>&1
sc config "CDPSvc" start= auto >nul 2>&1
sc config "ClipSVC" start= auto >nul 2>&1
sc config "CscService" start= auto >nul 2>&1
sc config "DevQueryBroker" start= auto >nul 2>&1
sc config "DevicesFlowUserSvc_5f1ad" start= auto >nul 2>&1
sc config "DiagTrack" start= auto >nul 2>&1
sc config "DialogBlockingService" start= auto >nul 2>&1
sc config "DispBrokerDesktopSvc" start= auto >nul 2>&1
sc config "DsSvc" start= auto >nul 2>&1
sc config "DsmSvc" start= auto >nul 2>&1
sc config "DusmSvc" start= auto >nul 2>&1
sc config "EFS" start= auto >nul 2>&1
sc config "FDResPub" start= auto >nul 2>&1
sc config "Fax" start= auto >nul 2>&1
sc config "FontCache" start= auto >nul 2>&1
sc config "IKEEXT" start= auto >nul 2>&1
sc config "InstallService" start= auto >nul 2>&1
sc config "MessagingService_5f1ad" start= auto >nul 2>&1
sc config "MicrosoftEdgeElevationService" start= auto >nul 2>&1
sc config "MixedRealityOpenXRSvc" start= auto >nul 2>&1
sc config "MsKeyboardFilter" start= auto >nul 2>&1
sc config "NPSMSvc" start= auto >nul 2>&1
sc config "NetTcpPortSharing" start= auto >nul 2>&1
sc config "OneSyncSvc" start= auto >nul 2>&1
sc config "OneSyncSvc_5f1ad" start= auto >nul 2>&1
sc config "PcaSvc" start= auto >nul 2>&1
sc config "PhoneSvc" start= auto >nul 2>&1
sc config "PimIndexMaintenanceSvc_5f1ad" start= auto >nul 2>&1
sc config "PrintNotify" start= auto >nul 2>&1
sc config "RasMan" start= auto >nul 2>&1
sc config "RetailDemo" start= auto >nul 2>&1
sc config "SEMgrSvc" start= auto >nul 2>&1
sc config "SSDPSRV" start= auto >nul 2>&1
sc config "SensorDataService" start= auto >nul 2>&1
sc config "SensorService" start= auto >nul 2>&1
sc config "SensrSvc" start= auto >nul 2>&1
sc config "SessionEnv" start= auto >nul 2>&1
sc config "Spooler" start= auto >nul 2>&1
sc config "SstpSvc" start= auto >nul 2>&1
sc config "SysMain" start= auto >nul 2>&1
sc config "TapiSrv" start= auto >nul 2>&1
sc config "TermService" start= auto >nul 2>&1
sc config "TokenBroker" start= auto >nul 2>&1
sc config "TrkWks" start= auto >nul 2>&1
sc config "UevAgentService" start= auto >nul 2>&1
sc config "UsoSvc" start= auto >nul 2>&1
sc config "W32Time" start= auto >nul 2>&1
sc config "WPDBusEnum" start= auto >nul 2>&1
sc config "WalletService" start= auto >nul 2>&1
sc config "WbioSrvc" start= auto >nul 2>&1
sc config "WebClient" start= auto >nul 2>&1
sc config "Wecsvc" start= auto >nul 2>&1
sc config "WerSvc" start= auto >nul 2>&1
sc config "WpcMonSvc" start= auto >nul 2>&1
sc config "WpnUserService_5f1ad" start= auto >nul 2>&1
sc config "XblAuthManager" start= auto >nul 2>&1
sc config "XblGameSave" start= auto >nul 2>&1
sc config "XboxGipSvc" start= auto >nul 2>&1
sc config "XboxNetApiSvc" start= auto >nul 2>&1
sc config "autotimesvc" start= auto >nul 2>&1
sc config "bthserv" start= auto >nul 2>&1
sc config "cbdhsvc" start= auto >nul 2>&1
sc config "dLauncherLoopback" start= auto >nul 2>&1
sc config "diagnosticshub.standardcollector.service" start= auto >nul 2>&1
sc config "diagsvc" start= auto >nul 2>&1
sc config "dmwappushservice" start= auto >nul 2>&1
sc config "edgeupdate" start= auto >nul 2>&1
sc config "edgeupdatem" start= auto >nul 2>&1
sc config "fdPHost" start= auto >nul 2>&1
sc config "icssvc" start= auto >nul 2>&1
sc config "WlanSvc" start= auto >nul 2>&1
sc config "vwififlt" start= auto >nul 2>&1
sc start "BITS" >nul 2>&1
sc start "BTAGService" >nul 2>&1
sc start "ClipSVC" >nul 2>&1
sc start "Spooler" >nul 2>&1
sc start "SysMain" >nul 2>&1
sc start "UsoSvc" >nul 2>&1
sc start "WlanSvc" >nul 2>&1
echo Done!
pause
goto main