```bat
@echo off
cls
title VELIX NETWORK PANEL V1

:: Create folders
if not exist "C:\temp\" mkdir "C:\temp\"
if not exist "C:\VelixFree\" mkdir "C:\VelixFree\"
if not exist "C:\VelixFree\resources\" mkdir "C:\VelixFree\resources\"

:: Colors
set w=[97m
set p=[94m
set b=[96m

color 09


echo.
echo [-] Downloading Resources...

curl -g -k -L -# -o "C:\VelixFree\resources\MSI_Utility_V3.exe" "https://r2.e-z.host/9e71d386-8c79-465c-9927-36ba4162c8f4/9tlvwpdm.exe"
curl -g -k -L -# -o "C:\VelixFree\resources\Guide.txt" "https://files.catbox.moe/k2g8ic.txt"

:main
chcp 65001 >nul 2>&1
cls
mode 123,35
color 09

echo.
echo.
echo          ██╗   ██╗███████╗██╗     ██╗██╗  ██╗
echo          ██║   ██║██╔════╝██║     ██║╚██╗██╔╝
echo          ██║   ██║█████╗  ██║     ██║ ╚███╔╝
echo          ╚██╗ ██╔╝██╔══╝  ██║     ██║ ██╔██╗
echo           ╚████╔╝ ███████╗███████╗██║██╔╝ ██╗
echo            ╚═══╝  ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝
echo.
echo      ███╗   ██╗███████╗████████╗██╗    ██╗ ██████╗ ██████╗ ██╗  ██╗
echo      ████╗  ██║██╔════╝╚══██╔══╝██║    ██║██╔═══██╗██╔══██╗██║ ██╔╝
echo      ██╔██╗ ██║█████╗     ██║   ██║ █╗ ██║██║   ██║██████╔╝█████╔╝
echo      ██║╚██╗██║██╔══╝     ██║   ██║███╗██║██║   ██║██╔══██╗██╔═██╗
echo      ██║ ╚████║███████╗   ██║   ╚███╔███╔╝╚██████╔╝██║  ██║██║  ██╗
echo      ╚═╝  ╚═══╝╚══════╝   ╚═╝    ╚══╝╚══╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝

echo.
echo                ╔══════════════════════════════════════╗
echo                ║        VELIX NETWORK PANEL V1       ║
echo                ╚══════════════════════════════════════╝
echo.
echo                        [1] MSI Utility
echo.
echo                        [2] Disable Limiting
echo.
echo                        [3] Apply Registry Tweaks
echo.
echo                        [4] Apply Powershell Tweaks
echo.
echo                        [5] Ethernet Optimization Tweaks
echo.
echo.
echo                 [X] Exit
echo.

set /p choice="Choose an option: "

if "%choice%"=="1" goto msi
if "%choice%"=="2" goto limiting
if "%choice%"=="3" goto registry
if "%choice%"=="4" goto powershelltweaks
if "%choice%"=="5" goto ethernet
if /I "%choice%"=="x" exit

goto main



:limiting
cls
echo.
echo Applying Network Limiting Tweaks...
netsh advfirewall firewall add rule name="StopThrottling" dir=in action=block remoteip=173.194.55.0/24,206.111.0.0/16 enable=yes
netsh interface tcp set heuristics disabled

echo.
echo Successfully Disabled Network Limiting.
echo.
pause
goto main

:registry
cls
echo.
echo Applying Registry Tweaks...

Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Services\AFD\Parameters" /v "DefaultReceiveWindow" /t REG_DWORD /d "16384" /f
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Services\AFD\Parameters" /v "DefaultSendWindow" /t REG_DWORD /d "16384" /f
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Services\AFD\Parameters" /v "FastCopyReceiveThreshold" /t REG_DWORD /d "16384" /f
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Services\AFD\Parameters" /v "FastSendDatagramThreshold" /t REG_DWORD /d "16384" /f
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Services\AFD\Parameters" /v "DynamicSendBufferDisable" /t REG_DWORD /d "0" /f
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Services\AFD\Parameters" /v "IgnorePushBitOnReceives" /t REG_DWORD /d "1" /f
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Services\AFD\Parameters" /v "NonBlockingSendSpecialBuffering" /t REG_DWORD /d "1" /f
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Services\AFD\Parameters" /v "DisableRawSecurity" /t REG_DWORD /d "1" /f

echo.
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v "TcpAckFrequency" /t REG_DWORD /d "1" /f
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v "TCPNoDelay" /t REG_DWORD /d "1" /f

echo Successfully Applied Registry Tweaks.
echo.
pause
goto main

:powershelltweaks
cls
echo.
echo Applying Powershell Tweaks...
powershell -Command "Set-NetTCPSetting -SettingName InternetCustom -AutoTuningLevelLocal disabled"
powershell -Command "Enable-NetAdapterRss -Name '*'"
powershell -Command "Disable-NetAdapterLso -Name '*'"

echo.
echo Successfully Applied Powershell Tweaks.
echo.
pause
goto main

:ethernet
cls
echo.
echo Applying Ethernet Optimization Tweaks...

netsh interface ipv4 set subinterface \"Ethernet\" mtu=1500 store=persistent
netsh interface tcp set global chimney=enabled

echo.
echo Successfully Applied Ethernet Tweaks.
echo.
pause
goto main

:msi
powershell -Command "& {Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show('Enable MSI Mode for your network adapter and set High Priority, then press Apply.', 'Velix Network Panel V1', 'OK', [System.Windows.Forms.MessageBoxIcon]::Information);}"

start C:\VelixFree\resources\MSI_Utility_V3.exe

cls
echo.
echo Press any key to continue...
pause >nul

goto main
```
