@echo off
cls
title VELIXKEYBOARDPANELV1
:: Check if C:\temp exists, if not, create it
if not exist "C:\temp\" mkdir "C:\temp\"

echo [-] Making folders in c: drive
md C:\velixfree\resources 2>nul

mode 140,30
set w=[97m
set p=[95m
set b=[96m

:main
chcp 65001 >nul 2>&1
cls
color 0
echo.
echo.
echo               ██╗   ██╗███████╗██╗     ██╗██╗  ██╗    ██████╗  █████╗ ███╗   ██╗███████╗██╗     
echo               ██║   ██║██╔════╝██║     ██║╚██╗██╔╝    ██╔══██╗██╔══██╗████╗  ██║██╔════╝██║     
echo               ██║   ██║█████╗  ██║     ██║ ╚███╔╝     ██████╔╝███████║██╔██╗ ██║█████╗  ██║     
echo               ╚██╗ ██╔╝██╔══╝  ██║     ██║ ██╔██╗     ██╔═══╝ ██╔══██║██║╚██╗██║██╔══╝  ██║     
echo                ╚████╔╝ ███████╗███████╗██║██╔╝ ██╗    ██║     ██║  ██║██║ ╚████║███████╗███████╗
echo                 ╚═══╝  ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝    ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═══╝╚══════╝╚══════╝
echo                                                 V E R S I O N   1
echo            -----------------------------------------------------------------------------------------------------------------
echo.
echo.
echo.
echo                                 [1] Disable Sticky Keys          [2] Extra Tweaks
echo.
echo.
echo                                 [3] Disable Game Bar/DVR         [4] Optimize System Timer
echo.
echo.
echo                                 [5] Optimize Input Latency       [6] Optimize Foreground Priority
echo.
echo.
set /p choice="Choose an option:"

if /I "%choice%"=="1" goto sticky
if /I "%choice%"=="2" goto extras
if /I "%choice%"=="3" goto gamedvr
if /I "%choice%"=="4" goto systimer
if /I "%choice%"=="5" goto inputlatency
if /I "%choice%"=="6" goto foreground
goto main

:sticky
cls
Reg.exe add "HKCU\Control Panel\Accessibility\MouseKeys" /v "Flags" /t REG_SZ /d "0" /f
Reg.exe add "HKCU\Control Panel\Accessibility\StickyKeys" /v "Flags" /t REG_SZ /d "0" /f
Reg.exe add "HKCU\Control Panel\Accessibility\Keyboard Response" /v "Flags" /t REG_SZ /d "0" /f
Reg.exe add "HKCU\Control Panel\Accessibility\ToggleKeys" /v "Flags" /t REG_SZ /d "0" /f
echo.
echo   Sticky Keys Disabled!
echo   Press Any Key to Continue
echo ==============================
echo.
pause
cls
goto main

:extras
cls
Reg.exe add "HKCU\Control Panel\Accessibility\Keyboard Response" /v "Flags" /t REG_DWORD /d "0" /f
Reg.exe add "HKCU\Control Panel\Keyboard" /v "KeyboardDelay" /t REG_SZ /d "0" /f
Reg.exe add "HKCU\Control Panel\Keyboard" /v "InitialKeyboardIndicators" /t REG_SZ /d "0" /f
Reg.exe add "HKCU\Control Panel\Keyboard" /v "KeyboardSpeed" /t REG_SZ /d "31" /f
Reg.exe add "HKCU\Control Panel\Accessibility\Keyboard Response" /v "DelayBeforeAcceptance" /t REG_SZ /d "0" /f
Reg.exe add "HKCU\Control Panel\Accessibility\Keyboard Response" /v "Last BounceKey Setting" /t REG_DWORD /d "0" /f
Reg.exe add "HKCU\Control Panel\Accessibility\Keyboard Response" /v "Last Valid Delay" /t REG_DWORD /d "0" /f
Reg.exe add "HKCU\Control Panel\Accessibility\Keyboard Response" /v "Last Valid Repeat" /t REG_DWORD /d "0" /f
Reg.exe add "HKCU\Control Panel\Accessibility\Keyboard Response" /v "Last Valid Wait" /t REG_DWORD /d "0" /f
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Services\kbdclass\Parameters" /v "ThreadPriority" /t REG_DWORD /d "31" /f

:: Disable Filter Keys completely
Reg.exe add "HKCU\Control Panel\Accessibility\FilterKeys" /v "Flags" /t REG_SZ /d "0" /f

:: Automatically set low Keyboard Data Queue Size
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Services\kbdclass\Parameters" /v "KeyboardDataQueueSize" /t REG_DWORD /d "16" /f

:: Device parameter loop
for /f "delims=" %%a in ('reg query "HKLM\System\CurrentControlSet\Enum" /s /f "Device Parameters" 2^>nul ^| findstr /i "Device Parameters"') do (
    Reg.exe add "%%a\WDF" /v IdleInWorkingState /t REG_DWORD /d 0 /f >nul 2>&1
    Reg.exe add "%%a" /v "EnhancedPowerManagementEnabled" /t REG_DWORD /d "0" /f >nul 2>&1
    Reg.exe add "%%a" /v "AllowIdleIrpInD3" /t REG_DWORD /d "0" /f >nul 2>&1
    Reg.exe add "%%a" /v "DeviceSelectiveSuspended" /t REG_DWORD /d "0" /f >nul 2>&1
    Reg.exe add "%%a" /v "SelectiveSuspendEnabled" /t REG_DWORD /d "0" /f >nul 2>&1
    Reg.exe add "%%a" /v "SelectiveSuspendOn" /t REG_DWORD /d "0" /f >nul 2>&1
    Reg.exe add "%%a" /v "fid_D1Latency" /t REG_DWORD /d "0" /f >nul 2>&1
    Reg.exe add "%%a" /v "fid_D2Latency" /t REG_DWORD /d "0" /f >nul 2>&1
    Reg.exe add "%%a" /v "fid_D3Latency" /t REG_DWORD /d "0" /f >nul 2>&1
)
echo.
echo   Extra Tweaks Applied Successfully!
echo   Press Any Key to Continue
echo ==============================
echo.
pause
cls
goto main

:gamedvr
cls
echo [-] Disabling Xbox Game Bar and Game DVR...
Reg.exe add "HKCU\System\GameConfigStore" /v "GameDVR_Enabled" /t REG_DWORD /d "0" /f
Reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR" /v "AllowGameDVR" /t REG_DWORD /d "0" /f
Reg.exe add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR" /v "AppCaptureEnabled" /t REG_DWORD /d "0" /f
echo.
echo   Game Bar and DVR Disabled!
echo   Press Any Key to Continue
echo ==============================
echo.
pause
goto main

:systimer
cls
echo [-] Optimizing System Timer for reduced input delay...
bcdedit /set disabledynamictick yes
bcdedit /set useplatformclock false
bcdedit /deletevalue useplatformtick >nul 2>&1
echo.
echo   System Timer Optimized! (A restart is required for this to take effect)
echo   Press Any Key to Continue
echo ==============================
echo.
pause
goto main

:inputlatency
cls
echo [-] Optimizing CSRSS Process for Input Latency...
Reg.exe add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\csrss.exe\PerfOptions" /v "CpuPriorityClass" /t REG_DWORD /d "4" /f
Reg.exe add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\csrss.exe\PerfOptions" /v "IoPriority" /t REG_DWORD /d "3" /f
echo.
echo   Input Latency Optimized!
echo   Press Any Key to Continue
echo ==============================
echo.
pause
goto main

:foreground
cls
echo [-] Optimizing Foreground Window Responsiveness...
Reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl" /v "Win32PrioritySeparation" /t REG_DWORD /d "38" /f
echo.
echo   Foreground Priority Optimized!
echo   Press Any Key to Continue
echo ==============================
echo.
pause
goto main